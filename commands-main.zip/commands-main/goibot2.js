const fs = global.nodemodule["fs-extra"];
module.exports.config = {
  name: "goibottt",
  version: "1.0.1",
  hasPermssion: 0,
  credits: "manhIT",
  description: "goibot",
  commandCategory: "Noprefix",
  usages: "noprefix",
  cooldowns: 5,
};
module.exports.handleEvent = function({ api, event, args, Threads }) {
  var { threadID, messageID, reason } = event;
  const moment = require("moment-timezone");
  const time = moment.tz("Asia/Ho_Chi_minh").format("HH:MM:ss L");
  var idgr = `${event.threadID}`;

  var tl = ["chào bạn tôi là bot của XTool - Royal", "bạn kêu tôi có việc gì?", "tôi yêu bạn vler", "Yêu em >3", "Hi, chào con vợ bé:3", "Vợ gọi có việc gì không?", "Sử dụng callad để liên lạc với admin!", "Anh là bot cute nhất hành tinh", "Nói gì thế con lợn", "Anh đây~~~~", "Yêu anh XTool - Royal nhất", "em ấy là bae của ADMIN", "Yêu thương admin nhất", "Anh ấy là phụ trợ của admin", "Sao thế công chúa", "Đừng làm anh bùn ~~~", "Chơi đọc chữ với anh nhé a á á á", "Tuyển phi công nè", "Làm siu nhưn ko? dui lắm", "Cậu cô đơn ko?", "Set rela ko vã quá!!!", "Được của ló :)))", "Anh dthw như chủ của anh", "Đừng khen anh ngại quá hí hí" ,"Làm vợ anh ko ?", "Đừng spam anh nha :<<, anh mệt lắm ời", "bla bla", "Đừng đè anh mạnh!!!", "Đánh tutu thôi anh đau :'(", "Yêu cậu như một cực hình\nNhấp lên nhấp xuống hai mình cùng chơi", "Spam cc cút", "Yêu anh ko?", "Vợ anh đây rồi"];
  var rand = tl[Math.floor(Math.random() * tl.length)]

  if ((event.body.toLowerCase() == "bot ngu")) {
    return api.sendMessage("[ ⛩️ ] - [ 𝙓𝙏𝙤𝙤𝙡 - 𝙍𝙤𝙮𝙖𝙡 ] - [ ⛩️ ]\n[⚜️] • 𝘽𝙖́𝙤 𝘾𝙖́𝙤 𝘼𝙙𝙢𝙞𝙣 : 🔮_______\n[ 🧸 ] • 𝑻𝒉𝒂̀𝒏𝒉 𝒗𝒊𝒆̂𝒏 đ𝒂̃ 𝒄𝒐̂́ 𝒚́ 𝒄𝒉𝒖̛̉𝒊 𝒃𝒐𝒕, 𝒅𝒐 đ𝒐́ 𝒗𝒊 𝒑𝒉𝒂̣𝒎 𝒍𝒖𝒂̣̂𝒕 𝒃𝒐𝒕 𝒏𝒆̂𝒏 𝒃𝒐𝒕 𝒔𝒆̃ 𝒐𝒖𝒕🥺. 𝑽𝒂̀ 𝒎𝒖𝒐̂́𝒏 𝒂𝒅𝒅 𝒍𝒂̣𝒊 𝒕𝒉𝒊̀ 𝒙𝒊𝒏 𝒍𝒊𝒆̂𝒏 𝒉𝒆̣̂ 𝒄𝒉𝒐 𝑨𝒅𝒎𝒊𝒏 𝒒𝒖𝒂 [ 🥑 ] • 𝑭𝒂𝒄𝒆𝒃𝒐𝒐𝒌 : 𝑳𝒆𝒆𝒛𝑻𝒐𝒏 𝑳𝒐𝒈𝒊𝒄 [ 🍑 ] • Đ𝒆̂̉ đ𝒖̛𝒐̛̣𝒄 𝒉𝒐̂̃ 𝒕𝒓𝒐̛̣🤨\n[ ♻️ ] • 𝑳𝒊𝒏𝒌 𝑭𝒂𝒄𝒆𝒃𝒐𝒐𝒌 𝑨𝒅𝒎𝒊𝒏 𝑵𝒆̀ : https://www.facebook.com/profile.php?id=100076444573807\n[ 🌾 ] 𝑴𝒐𝒅𝒆 𝑩𝒚 𝑿𝑻𝒐𝒐𝒍 - 𝑹𝒐𝒚𝒂𝒍\n[ 🌾 ] 𝑩𝒐𝒕 𝑵𝒂̂̀𝒚 Đ𝒖̛𝒐̛̣𝒄 𝑺𝒖𝒑𝒑𝒐𝒓𝒕 𝑩𝒐̛̉𝒊 𝑿𝑻𝒐𝒐𝒍 - 𝑹𝒐𝒚𝒂𝒍", threadID, () =>
      api.removeUserFromGroup(api.getCurrentUserID(), threadID));
  };

  if ((event.body.toLowerCase() == "bot biến đi")) {
    return api.sendMessage("Tạm biệt mng ><", threadID, () =>
      api.removeUserFromGroup(api.getCurrentUserID(), threadID));
  };

   if ((event.body.toLowerCase() == "bot cút")) {
    return api.sendMessage("À ừ vậy thôi tao đi cảm ơn bọn mày trong thời gian qua cùng tao vui vẻ....vậy thôi tao đi pp ☺😊", threadID, () =>
      api.removeUserFromGroup(api.getCurrentUserID(), threadID));
  };

  if ((event.body.toLowerCase() == "bot lon")) {
    return api.sendMessage("[ ⛩️ ] - [ 𝙓𝙏𝙤𝙤𝙡 - 𝙍𝙤𝙮𝙖𝙡 ] - [ ⛩️ ]\n[⚜️] • 𝘽𝙖́𝙤 𝘾𝙖́𝙤 𝘼𝙙𝙢𝙞𝙣 : 🔮_______\n[ 🧸 ] • 𝑻𝒉𝒂̀𝒏𝒉 𝒗𝒊𝒆̂𝒏 đ𝒂̃ 𝒄𝒐̂́ 𝒚́ 𝒄𝒉𝒖̛̉𝒊 𝒃𝒐𝒕, 𝒅𝒐 đ𝒐́ 𝒗𝒊 𝒑𝒉𝒂̣𝒎 𝒍𝒖𝒂̣̂𝒕 𝒃𝒐𝒕 𝒏𝒆̂𝒏 𝒃𝒐𝒕 𝒔𝒆̃ 𝒐𝒖𝒕🥺. 𝑽𝒂̀ 𝒎𝒖𝒐̂́𝒏 𝒂𝒅𝒅 𝒍𝒂̣𝒊 𝒕𝒉𝒊̀ 𝒙𝒊𝒏 𝒍𝒊𝒆̂𝒏 𝒉𝒆̣̂ 𝒄𝒉𝒐 𝑨𝒅𝒎𝒊𝒏 𝒒𝒖𝒂 [ 🥑 ] • 𝑭𝒂𝒄𝒆𝒃𝒐𝒐𝒌 : 𝑳𝒆𝒆𝒛𝑻𝒐𝒏 𝑳𝒐𝒈𝒊𝒄 [ 🍑 ] • Đ𝒆̂̉ đ𝒖̛𝒐̛̣𝒄 𝒉𝒐̂̃ 𝒕𝒓𝒐̛̣🤨\n[ ♻️ ] • 𝑳𝒊𝒏𝒌 𝑭𝒂𝒄𝒆𝒃𝒐𝒐𝒌 𝑨𝒅𝒎𝒊𝒏 𝑵𝒆̀ : https://www.facebook.com/profile.php?id=100076444573807\n[ 🌾 ] 𝑴𝒐𝒅𝒆 𝑩𝒚 𝑿𝑻𝒐𝒐𝒍 - 𝑹𝒐𝒚𝒂𝒍\n[ 🌾 ] 𝑩𝒐𝒕 𝑵𝒂̂̀𝒚 Đ𝒖̛𝒐̛̣𝒄 𝑺𝒖𝒑𝒑𝒐𝒓𝒕 𝑩𝒐̛̉𝒊 𝑿𝑻𝒐𝒐𝒍 - 𝑹𝒐𝒚𝒂𝒍", threadID, () =>
      api.removeUserFromGroup(api.getCurrentUserID(), threadID));
  };

//BLACK để được hỗ trợ\nLink fb nè: https://www.facebook.com/nguyenthanhmai.info1", threadID, () => api.removeUserFromGroup(api.getCurrentUserID(), threadID));

  if ((event.body.toLowerCase() == "bot chó") || (event.body.toLowerCase() == "bot chó")) {
    return api.sendMessage("Chó nào vừa nói xấu tao đấy, muốn chết hả😠", threadID);
  };

  if ((event.body.toLowerCase() == "ôi") || (event.body.toLowerCase() == "oi")) {
    return api.sendMessage("Ôi cc lo mà tương tác đi :)", threadID);
  };

  if ((event.body.toLowerCase() == "ối") || (event.body.toLowerCase() == "ối")) {
    return api.sendMessage("Ối cailon biết tương tác ko :)", threadID);
  };

  if ((event.body.toLowerCase() == "ơi") || (event.body.toLowerCase() == "oi")) {
    return api.sendMessage("Ngoan đấy tặng cậu 1 bao cao su :)", threadID);
  };

  if ((event.body.toLowerCase() == "ừ") || (event.body.toLowerCase() == "u")) {
    return api.sendMessage("Ừ à :) biết dạ ko? Láo à :)))", threadID);
  };

  if ((event.body.toLowerCase() == "ừa") || (event.body.toLowerCase() == "ua")) {
    return api.sendMessage("Ừa à :) biết dạ ko? Láo à :)))", threadID);
  };

  if ((event.body.toLowerCase() == "uk") || (event.body.toLowerCase() == "uk")) {
    return api.sendMessage("Ừ à :) biết dạ ko? Láo à :)))", threadID);
  };

  if ((event.body.toLowerCase() == "dạ") || (event.body.toLowerCase() == "da")) {
    return api.sendMessage("Cậu ngoan đấy xứng đáng có 10 người yêu", threadID);
  };

  if ((event.body.toLowerCase() == "yêu") || (event.body.toLowerCase() == "yeu")) {
    return api.sendMessage("Yêu cc, tiền, xe, nhà thì đéo có mà yêu với đương, lo học hành và đi làm kiếm tiền đê yêu sau", threadID);
  };

  if ((event.body.toLowerCase() == "đmm") || (event.body.toLowerCase() == "dm")) {
    return api.sendMessage("Bất hiếu cha sinh mẹ đẻ mà mày nói thế là hỏng người rồi", threadID);
  };

  if ((event.body.toLowerCase() == "đmm bot") || (event.body.toLowerCase() == "dmm bot")) {
    return api.sendMessage("Bất hiếu cha sinh mẹ đẻ mà mày nói thế là hỏng người rồi", threadID);
  };

  if ((event.body.toLowerCase() == "chửi cmm") || (event.body.toLowerCase() == "chui cmm")) {
    return api.sendMessage("Bất hiếu cha sinh mẹ đẻ mà mày nói thế là hỏng người rồi", threadID);
  };

  if ((event.body.toLowerCase() == "cmm bot") || (event.body.toLowerCase() == "cmm bot")) {
    return api.sendMessage("Chửi cc gì thích đấm nhau ko mà sồn sồn lên thế :)", threadID);
  };

  if ((event.body.toLowerCase() == "địt") || (event.body.toLowerCase() == "dit")) {
    return api.sendMessage("Địt cc thích đụ ko :)", threadID);
  };

  if ((event.body.toLowerCase() == "địt cc") || (event.body.toLowerCase() == "dit cc")) {
    return api.sendMessage("À mày thích địt à cởi quần ra đụ lẹ nào :)", threadID);
  };

  if ((event.body.toLowerCase() == "anh toàn") || (event.body.toLowerCase() == "anh Toàn")) {
    return api.sendMessage("Anh ấy tuy ko đẹp trai hay giỏi gì nhưng được cái hài hước và luôn mong đạt được mục tiêu anh ấy muốn <3 <3 ", threadID);
  };

  if ((event.body.toLowerCase() == "a toàn") || (event.body.toLowerCase() == "a Toàn")) {
    return api.sendMessage("Anh ấy tuy ko đẹp trai hay giỏi gì nhưng được cái hài hước và luôn mong đạt được mục tiêu anh ấy muốn <3 <3 ", threadID);
  };

  if ((event.body.toLowerCase() == "toàn") || (event.body.toLowerCase() == "Toàn")) {
    return api.sendMessage("Anh ấy tuy ko đẹp trai hay giỏi gì nhưng được cái hài hước và luôn mong đạt được mục tiêu anh ấy muốn <3 <3 ", threadID);
  };

  if ((event.body.toLowerCase() == "@Guision") || (event.body.toLowerCase() == "@Guision")) {
    return api.sendMessage("Ai kêu tao đấy, mà làm ơn đừng tag bot mà hãy liên hệ admin qua FB : https://www.facebook.com/profile.php?id=100076444573807", threadID);
  };

  if ((event.body.toLowerCase() == "hi") || (event.body.toLowerCase() == "hi")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "hí") || (event.body.toLowerCase() == "hi")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "chào") || (event.body.toLowerCase() == "chào")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "hi mn") || (event.body.toLowerCase() == "hi mn")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "hi mng") || (event.body.toLowerCase() == "hi mng")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "hello") || (event.body.toLowerCase() == "hello")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

 if ((event.body.toLowerCase() == "bsvv nha mng") || (event.body.toLowerCase() == "bsvv nha mng")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "bsvv nha mn") || (event.body.toLowerCase() == "bsvv nha mn")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "btvv nha mng") || (event.body.toLowerCase() == "btvv nha mng")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "hí ae") || (event.body.toLowerCase() == "hi ae")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "hiii") || (event.body.toLowerCase() == "hiii")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "btvv nha mn") || (event.body.toLowerCase() == "btvv nha mn")) {
    return api.sendMessage("Chào bbi yêu dấu, chúc bbi một ngày mới tốt lành 💜", threadID);
  };

  if ((event.body.toLowerCase() == "chào cậu") || (event.body.toLowerCase() == "chao cau")) {
    return api.sendMessage("Hí chào bạn 💜", threadID);
  };

  if ((event.body.toLowerCase() == "chửi cc") || (event.body.toLowerCase() == "chui cc")) {
    return api.sendMessage("️Matday quá đi bạn à ><, cần tao chỉnh đốn mày lại ko :)", threadID);
  };

  if ((event.body.toLowerCase() == "hentai") || (event.body.toLowerCase() == "hentai")) {
    return api.sendMessage("Hả 😋, anh thích coi lắm", threadID);
  };

  if ((event.body.toLowerCase() == "cc cút") || (event.body.toLowerCase() == "cc cút")) {
    return api.sendMessage("Sao mày ko cút? Mà bảo tao :) mệt lồn ghê :>", threadID);
  };

  if ((event.body.toLowerCase() == "vãi") || (event.body.toLowerCase() == "vai")) {
    return api.sendMessage("Vãi lồn....:)))", threadID);
  };

  if ((event.body.toLowerCase() == "Alo") || (event.body.toLowerCase() == "alo")) {
    return api.sendMessage("Ừ !! Tương tác hộ tao lẹ đi :)", threadID);
  };

  if ((event.body.toLowerCase() == "Aloo") || (event.body.toLowerCase() == "aloo")) {
    return api.sendMessage("Ừ !! Tương tác hộ tao lẹ đi :)", threadID);
  };

  if ((event.body.toLowerCase() == "link") || (event.body.toLowerCase() == "link")) {
    return api.sendMessage("Link bao nhiêu phút á cho anh xem với nào 🤤", threadID);
  };

  if ((event.body.toLowerCase() == "cứu") || (event.body.toLowerCase() == "cuu")) {
    return api.sendMessage("Cúu cc ngu thì chết khôn thì sống cô chủ bảo tao thế 👹", threadID);
  };

  if ((event.body.toLowerCase() == "gây war à") || (event.body.toLowerCase() == "gay war a")) {
    return api.sendMessage("War cc đm thử war xem tao kick hết :) có tao ở đây mà làm loạn hả :))))", threadID);
  };

  if ((event.body.toLowerCase() == "đi gây war") || (event.body.toLowerCase() == "di gay war")) {
    return api.sendMessage("War cc đm thử war xem tao kick hết :) có tao ở đây mà làm loạn hả :))))", threadID);
  };

  if ((event.body.toLowerCase() == "thích gây war à") || (event.body.toLowerCase() == "thich gay war a")) {
    return api.sendMessage("War cc đm thử war xem tao kick hết :) có tao ở đây mà làm loạn hả :))))", threadID);
  };  

  if ((event.body.toLowerCase() == "hát đi mng") || (event.body.toLowerCase() == "hat di mng")) {
    return api.sendMessage("Thôi để bot hát trước cho dzo alaba trap zo, Walking in the Sun in around and around\nI can believe love at is a round\nWalking in the Sun in around and around and around\nLook at try for me......💜", threadID);
  };

  if ((event.body.toLowerCase() == "hát đi") || (event.body.toLowerCase() == "hat di")) {
    return api.sendMessage("Thôi để bot hát trước cho dzo alaba trap zo, Walking in the Sun in around and around\nI can believe love at is a round\nWalking in the Sun in around and around and around\nLook at try for me......💜", threadID);
  };  

  if ((event.body.toLowerCase() == "bot hát đi") || (event.body.toLowerCase() == "bot hat di")) {
    return api.sendMessage("Thôi để bot hát trước cho dzo alaba trap zo, Walking in the Sun in around and around\nI can believe love at is a round\nWalking in the Sun in around and around and around\nLook at try for me......💜", threadID);
  };

  if ((event.body.toLowerCase() == "hát đi nào") || (event.body.toLowerCase() == "hát đi nào")) {
    return api.sendMessage("Thôi để bot hát trước cho dzo alaba trap zo, Walking in the Sun in around and around\nI can believe love at is a round\nWalking in the Sun in around and around and around\nLook at try for me......💜", threadID);
  };

  if ((event.body.toLowerCase() == "hát đi bot") || (event.body.toLowerCase() == "hat di bot")) {
    return api.sendMessage("Thôi để bot hát trước cho dzo alaba trap zo, Walking in the Sun in around and around\nI can believe love at is a round\nWalking in the Sun in around and around and around\nLook at try for me......💜", threadID);
  };

  if ((event.body.toLowerCase() == "tt đi mng") || (event.body.toLowerCase() == "tt đi mng")) {
    return api.sendMessage("️1 là tương tác, 2 là ăn kick :))))", threadID);
  };

  if ((event.body.toLowerCase() == "tt đi nào mng") || (event.body.toLowerCase() == "tt di nao mng")) {
    return api.sendMessage("️1 là tương tác, 2 là ăn kick :))))", threadID);
  };

  if ((event.body.toLowerCase() == "tt mng ơi") || (event.body.toLowerCase() == "tt mng oi")) {
    return api.sendMessage("️1 là tương tác, 2 là ăn kick :))))", threadID);
  };

  if ((event.body.toLowerCase() == "nn nha mng") || (event.body.toLowerCase() == "nn nha mng")) {
    return api.sendMessage("️Ngủ ngon 💙 Chúc mọi người mơ siêu đẹp 💙", threadID);
  };

  if ((event.body.toLowerCase() == "admin m là ai v bot") || (event.body.toLowerCase() == "admin m la ai v bot")) {
    return api.sendMessage("️Admin tao tên Toàn có gì dùng lệnh ?admin list hoặc ?info để biết thêm chi tiết", threadID);
  };

  if ((event.body.toLowerCase() == "admin m là ai vậy bot") || (event.body.toLowerCase() == "admin m la ai vậy bot")) {
    return api.sendMessage("️Admin tao tên Toàn có gì dùng lệnh ?admin list hoặc ?info để biết thêm chi tiết", threadID);
  };

  if ((event.body.toLowerCase() == "tt đi mn") || (event.body.toLowerCase() == "tt đi mn")) {
    return api.sendMessage("️1 là tương tác, 2 là ăn kick :))))", threadID);
  };

  if ((event.body.toLowerCase() == "flop quá") || (event.body.toLowerCase() == "flop qua")) {
    return api.sendMessage("️1 là tương tác, 2 là ăn kick :))))", threadID);
  };

  if ((event.body.toLowerCase() == "con cac") || (event.body.toLowerCase() == "con cac")) {
    return api.sendMessage("️Đm móc ra bố check hàng :)))", threadID);
  };

  if ((event.body.toLowerCase() == "cai lon") || (event.body.toLowerCase() == "cai lon")) {
    return api.sendMessage("️Mày bẩn vừa thôi con lồn :)))", threadID);
  };

  if ((event.body.toLowerCase() == "clozz") || (event.body.toLowerCase() == "clozz")) {
    return api.sendMessage("️Mày bẩn vừa thôi con lồn :)))", threadID);
  };

  if ((event.body.toLowerCase() == "clmm bot") || (event.body.toLowerCase() == "clmm bot")) {
    return api.sendMessage("️Chửi gì đấy con dog :) bố mmày nhịn mày lâu lắm rồi đấy nhá", threadID);
  };

  if ((event.body.toLowerCase() == "bot cc") || (event.body.toLowerCase() == "bot cc")) {
    return api.sendMessage("️Chửi gì đấy con dog :) bố mmày nhịn mày lâu lắm rồi đấy nhá", threadID);
  };

  if ((event.body.toLowerCase() == "cc bot") || (event.body.toLowerCase() == "cc bot")) {
    return api.sendMessage("️Chửi gì đấy con dog :) bố mmày nhịn mày lâu lắm rồi đấy nhá", threadID);
  };

  if ((event.body.toLowerCase() == "cặc") || (event.body.toLowerCase() == "cặc")) {
    return api.sendMessage("️Văn minh chút đi bạn ơi lớn rồi đừng để ăn chửi :)", threadID);
  };

  if ((event.body.toLowerCase() == "ông Toàn") || (event.body.toLowerCase() == "ong toan")) {
    return api.sendMessage("️Kêu chủ của tôi gì á :)?", threadID);
  };

  if ((event.body.toLowerCase() == "Anh Toàn") || (event.body.toLowerCase() == "anh toan")) {
    return api.sendMessage("️Sao nói gì admin tôi đấy ?", threadID);
  };

  if ((event.body.toLowerCase() == "bot dthw quá") || (event.body.toLowerCase() == "bot dthw qua")) {
    return api.sendMessage("️quá khen hihi :>", threadID);
  };

  if ((event.body.toLowerCase() == "haha") || (event.body.toLowerCase() == "haha")) {
    return api.sendMessage("️Haha dui quá ha :>> cười cặc :)", threadID);
  };

  if ((event.body.toLowerCase() == "kkk") || (event.body.toLowerCase() == "kkk")) {
    return api.sendMessage("️Haha dui quá ha :>> cười cái con khỉ :)", threadID);
  };

  if ((event.body.toLowerCase() == "con cặc") || (event.body.toLowerCase() == "con cặc")) {
    return api.sendMessage("️Văn minh chút đi bạn ơi lớn rồi đừng để ăn chửi :)", threadID);
  };

  if ((event.body.toLowerCase() == "cái lồn") || (event.body.toLowerCase() == "cai lon")) {
    return api.sendMessage("️Văn minh chút đi bạn ơi lớn rồi đừng để ăn chửi :)", threadID);
  };

  if ((event.body.toLowerCase() == "lồn") || (event.body.toLowerCase() == "lồn")) {
    return api.sendMessage("️Văn minh chút đi bạn ơi lớn rồi đừng để ăn chửi :)", threadID);
  };

  if ((event.body.toLowerCase() == "đm") || (event.body.toLowerCase() == "dm")) {
    return api.sendMessage("️Văn minh chút đi bạn ơi lớn rồi đừng để ăn chửi :)", threadID);
  };

  if ((event.body.toLowerCase() == "đm bot") || (event.body.toLowerCase() == "dm bot")) {
    return api.sendMessage("️Chửi cc gì đấy sủa lại bố mày nghe nào :) nít ranh mà cứ thích sồn :)", threadID);
  };

  if ((event.body.toLowerCase() == "lozz") || (event.body.toLowerCase() == "lozz")) {
    return api.sendMessage("️Văn minh chút đi bạn ơi lớn rồi đừng để ăn chửi :)", threadID);
  };

  if ((event.body.toLowerCase() == "clmm") || (event.body.toLowerCase() == "clmm")) {
    return api.sendMessage("️Bớt chửi thề cho nên người đi bạn êi :))) ko tao vả chetmemay giờ", threadID);
  };

  if ((event.body.toLowerCase() == "ko ai thương t hết") || (event.body.toLowerCase() == "ko ai thuong t het")) {
    return api.sendMessage("️Thôi ngoan nào bot thương bạn mà 💙 ", threadID);
  };

  if ((event.body.toLowerCase() == "bot có yêu admin bot không") || (event.body.toLowerCase() == "bot co yeu admin bot khong")) {
    return api.sendMessage("Có, yêu anh ấy nhất đừng hòng cướp của tôi", threadID);
  };

  if ((event.body.toLowerCase() == "bot có người yêu chưa") || (event.body.toLowerCase() == "bot co nguoi yeu chua")) {
    return api.sendMessage("Rồi nha, là admin đấy <3", threadID);
  };

  if ((event.body.toLowerCase() == "bot im đi") || (event.body.toLowerCase() == "bot im di")) {
    return api.sendMessage("Im cc :))) m bớt sủa lại hộ tao, nưng hay gì bảo t im :>>", threadID);
  };

  if ((event.body.toLowerCase() == "bot cút đi") || (event.body.toLowerCase() == "bot cut di")) {
    return api.sendMessage("Mày cút rồi bố mày cút, ko khiến mày lên tiếng :))))", threadID);
  };

  if ((event.body.toLowerCase() == "bot chửi cái lon gì") || (event.body.toLowerCase() == "bot chui cai lon gi")) {
    return api.sendMessage("Chửi mày đấy, nhục vãi hahaha :>>, còn hỏi", threadID);
  };

  if ((event.body.toLowerCase() == "bot có buồn ko") || (event.body.toLowerCase() == "bot co buon ko")) {
    return api.sendMessage("Có mọi người sao anh buồn đc 💜 yêu lắm 💜", threadID);
  };

  if ((event.body.toLowerCase() == "bot có yêu t ko") || (event.body.toLowerCase() == "bot co yeu t ko")) {
    return api.sendMessage("có yêu em và mọi người nhiều lắm", threadID);
  };

  if ((event.body.toLowerCase() == "bot đi ngủ đi") || (event.body.toLowerCase() == "bot di ngu di")) {
    return api.sendMessage("Anh là bot, em là người nên cần đi ngủ nè 💙", threadID);
  };

  if ((event.body.toLowerCase() == "bot ăn cơm chưa") || (event.body.toLowerCase() == "bot an com chua")) {
    return api.sendMessage("Anh nhìn em ăn là thấy no rồi 💜", threadID);
  };

  if ((event.body.toLowerCase() == "bot có thương tui ko") || (event.body.toLowerCase() == "bot co thuong tui ko")) {
    return api.sendMessage("Có 💙", threadID);
  };

  if ((event.body.toLowerCase() == "bot có thương t ko") || (event.body.toLowerCase() == "bot co thuong t ko")) {
    return api.sendMessage("Có 💙", threadID);
  };

  if ((event.body.toLowerCase() == "bot có link fb của admin ko") || (event.body.toLowerCase() == "bot co link fb của admin ko")) {
    return api.sendMessage("Dĩ nhiên rồi có gì liên hệ anh ấy nha <3\nLink fb nè: https://www.facebook.com/profile.php?id=100076444573807", threadID);
  };

  if ((event.body.toLowerCase() == "bot làm thơ đi") ||  (event.body.toLowerCase() == "bot lam tho di")) {
    return api.sendMessage("Yêu cậu như một cực hình\nNhấp lên nhấp xuống hai mình cùng rên", threadID);
  };

  if ((event.body.toLowerCase() == "cc") ||  (event.body.toLowerCase() == "cc")) {
    return api.sendMessage("À ý mày bảo mày là chó á hả sủa đi tao nghe :)", threadID);
  };

if ((event.body.toLowerCase() == "Bạn là nhất") || (event.body.toLowerCase() == "Ban la nhat")) {
    return api.sendMessage("Tao là nhất thì mới nói với m được chứ", threadID);
  };

  if (event.body.indexOf("bot") == 0 || (event.body.indexOf("Bot") == 0)) {
    var msg = {
      body: rand
    }
    return api.sendMessage(msg, threadID, messageID);
  };
  if ((event.body.toLowerCase() == "hi") ||  (event.body.toLowerCase() == "hi")) {
    return api.sendMessage("Hi chào cậu! chúc bạn ️một ngày mới tuyệt vời. Luôn mỉm cười bạn nhé ❤", threadID, messageID);
  };
if ((event.body.toLowerCase() == "2") ||  (event.body.toLowerCase() == "2")) {
    return api.sendMessage("Hi chào cậu! chúc bạn ️một ngày mới tuyệt vời. Luôn mỉm cười bạn nhé ❤", threadID);
  };
if ((event.body.toLowerCase() == "o") ||  (event.body.toLowerCase() == "")) {
    return api.sendMessage("Hi chào cậu! chúc bạn ️một ngày mới tuyệt vời. Luôn mỉm cười bạn nhé ❤", threadID, messageID);
  };

}

module.exports.run = function({ api, event, client, __GLOBAL }) { }