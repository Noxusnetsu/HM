module.exports.config = {
    name: "ren",
    version: "1.0.1",
    hasPermssion: 0,
    credits: "JRT",
    description: "",
    commandCategory: "box chat",
    usages: "",
    cooldowns: 0,
    denpendencies: {
        "fs": "",
        "request": ""
    }
};
/*module.exports.onLoad = () => {
    const fs = require("fs-extra");
    const request = require("request");
    const dirMaterial = __dirname + `/cache/`;
    if (!fs.existsSync(dirMaterial + "cache")) fs.mkdirSync(dirMaterial, { recursive: true });
    if (!fs.existsSync(dirMaterial + "joinn.mp3")) request("https://files.catbox.moe/beeg7p.mp3").pipe(fs.createWriteStream(dirMaterial + "joinn.mp3"));
}*/
module.exports.handleEvent = async ({ event, api, Currencies,Users, args, utils, global, client }) => {
    const fs = require("fs");
    const axios = require('axios');
    const img = ["https://files.catbox.moe/sesrji.mp4"]

	var path = __dirname + "/cache/ren.mp4"
	var rdimg = img[Math.floor(Math.random() * img.length)]; 
	const imgP = []
	let dowloadIMG = (await axios.get(rdimg, { responseType: "arraybuffer" } )).data; 
	fs.writeFileSync(path, Buffer.from(dowloadIMG, "utf-8") );
	imgP.push(fs.createReadStream(path))
    const moment = require("moment-timezone");
    var gio = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss");
    const PREFIX = config.PREFIX
    let name = await Users.getNameUser(event.senderID)
    var msg = {
                body: `hehe `, attachment: imgP}
    if (event.body.toLowerCase() == "ren"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
    if (event.body.toLowerCase() == "prefix"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
    if (event.body.toLowerCase() == "daulenh"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
    if (event.body.toLowerCase() == "dấu lệnh"){
        return api.sendMessage(msg,event.threadID,event.messageID);}             
        };

module.exports.run = async ({ event, api, Currencies, args, utils }) => {
return api.sendMessage("Dùng sai cách rồi lêu lêu",event.threadID)
    }
  