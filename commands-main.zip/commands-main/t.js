<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-S72LBY47R8"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', "G-S72LBY47R8");
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>module.exports.config = {  name: &quot;t&quot;,  version: &quot;1.0.3&quot;,  hasPermssion: 0, - Pastebin.com</title>
    <link rel="shortcut icon" href="/favicon.ico" />
    <meta name="description" content="Pastebin.com is the number one paste tool since 2002. Pastebin is a website where you can store text online for a set period of time." />
    <meta property="og:description" content="Pastebin.com is the number one paste tool since 2002. Pastebin is a website where you can store text online for a set period of time." />
            <meta property="fb:app_id" content="231493360234820" />
    <meta property="og:title" content="module.exports.config = {  name: &quot;t&quot;,  version: &quot;1.0.3&quot;,  hasPermssion: 0, - Pastebin.com" />
    <meta property="og:type" content="article" />
    <meta property="og:url" content="https://pastebin.com/rmCrGRZA" />
    <meta property="og:image" content="https://pastebin.com/i/facebook.png" />
    <meta property="og:site_name" content="Pastebin" />
    <meta name="google-site-verification" content="jkUAIOE8owUXu8UXIhRLB9oHJsWBfOgJbZzncqHoF4A" />
    <link rel="canonical" href="https://pastebin.com/rmCrGRZA" />
        <meta name="csrf-param" content="_csrf-frontend">
<meta name="csrf-token" content="ORMC0ZBgSi0ZEIiiovvvRgE2MpX-7VrqYIGJr_NcE0QLeDWkolcQcnpH45qWlYd_aldW3bGeMJkuzb34viZ6Nw==">

<link href="/assets/c80611c4/css/bootstrap.min.css" rel="stylesheet">        
<link href="/themes/pastebin/css/vendors.bundle.css?9805bb637d58af16e68f" rel="stylesheet">
<link href="/themes/pastebin/css/app.bundle.css?9805bb637d58af16e68f" rel="stylesheet">
    
<!-- 0-x2xy94pJ -->
<script type="text/javascript" src="//services.vlitag.com/adv1/?q=adf050ece17b957604b4bbfc1829059f" defer="" async=""></script><script> var vitag = vitag || {};</script>
<!-- End Valueimpression Head Script -->
<script>
     vitag.smartBannerConfig= {
          disablePosition:  "top right left",
     }
</script>
<script type="text/javascript">
        if (window.location.pathname === "/") {
            vitag = vitag || {};
            vitag.outStreamConfig = vitag.outStreamConfig || {};
            vitag.outStreamConfig.enablePC = false;
        }
    </script>
</head>
<body class="night-auto " data-pr="x2xy94pJ" data-pa="" data-sar="1" data-abd="1">


<div class="wrap">

        
        
<div class="header">
    <div class="container">
        <div class="header__container">

                        <div class="header__left">
                <a class="header__logo" href="/">
                    Pastebin                </a>

                <div class="header__links h_1024">
                    
                                        <a href="/doc_api">API</a>
                    <a href="/tools">tools</a>
                    <a href="/faq">faq</a>
                                    </div>

                
                <a class="header__btn" href="/">
                    paste                </a>

                            </div>

                        <div class="header__right">

                                    <div class="header_sign">
                        <a href="/login" class="btn-sign sign-in">Login</a>
                        <a href="/signup" class="btn-sign sign-up">Sign up</a>
                    </div>
                
            </div>

        </div>
    </div>

</div>
        

    <div class="container">
        <div class="content">

                        
                        
<!-- 0-x2xy94pJ -->
<div style="padding-bottom:30px; padding-top:5px;width:998px;height:290px;">
<div style="color: #999; font-size: 12px; text-align: center;">Advertisement</div>
<div class="adsbyvli" data-ad-slot="vi_1282550010"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_1282550010")})</script>
</div>

                                    
            
            
<link href="/themes/pastebin/css/geshi/light/text.css?694707f98000ed24d865" rel="stylesheet">

<div class="post-view js-post-view">

    
    <div class="details">
                    <div class="share h_800">
                <div data-url="https://pastebin.com/rmCrGRZA" class="share-btn facebook js-facebook-share" title="Share on Facebook!"><span>SHARE</span></div>
                <div data-url="https://pastebin.com/rmCrGRZA" class="share-btn twitter js-twitter-share" title="Share on Twitter!"><span>TWEET</span></div>
            </div>
                <div class="user-icon">
                            <img src="/themes/pastebin/img/guest.png" alt="Guest User">                    </div>
        <div class="info-bar">
            <div class="info-top">

                
                
                                    <h1>Untitled</h1>
                            </div>
            <div class="info-bottom">

                                    <div class="username">
                        a guest                    </div>
                
                <div class="date">
                    <span title="Tuesday 19th of July 2022 09:14:24 AM CDT">Jul 19th, 2022</span>

                                    </div>

                <div class="visits" title="Unique visits to this paste">
                    6                </div>

                <div class="expire" title="When this paste gets automatically deleted">
                    Never                </div>

                
            </div>
        </div>
    </div>

    
    
                        <div class="page">
                <div class="content__text -no-padding">
                    <div class="notice -post-view">
                        <b>Not a member of Pastebin yet?</b>
                        <a href="/signup"><b><u>Sign Up</u></b></a>,
                        it unlocks many cool features!                    </div>
                </div>
            </div>
        
    
    <div class="highlighted-code">
        <div class="top-buttons">
            <div class="left">
                <a href="/archive/text" class="btn -small h_800">text</a> 1.42 KB            </div>

            <div class="right">
                                    <span class="copy__result -btn js-copy-success">Copied</span>
                    <a href="#" class="btn -small js-copy-raw" title="Copy raw to clipboard">copy</a>
                
                                    <a href="/raw/rmCrGRZA" class="btn -small">raw</a>
                    <a href="/dl/rmCrGRZA" class="btn -small">download</a>
                    <a href="/clone/rmCrGRZA" class="btn -small h_800">clone</a>
                    <a href="/embed/rmCrGRZA" class="btn -small h_800">embed</a>
                    <a href="/print/rmCrGRZA" class="btn -small h_800">print</a>
                
                                    <a href="/report/rmCrGRZA" class="btn -small">report</a>
                
                
                            </div>
        </div>
        <div class="source text" style="font-size: px; line-height: px;">
            <ol class="text"><li class="li1"><div class="de1">module.exports.config = {</div></li><li class="li1"><div class="de1">  name: &quot;t&quot;,</div></li><li class="li1"><div class="de1">  version: &quot;1.0.3&quot;,</div></li><li class="li1"><div class="de1">  hasPermssion: 0,</div></li><li class="li1"><div class="de1">  credits: &quot;Thiệu Trung Kiên&quot;,</div></li><li class="li1"><div class="de1">  description: &quot;Command Prompt&quot;,</div></li><li class="li1"><div class="de1">  commandCategory: &quot;tiện ích&quot;,</div></li><li class="li1"><div class="de1">  cooldowns: 5,</div></li><li class="li1"><div class="de1">  dependencies: {</div></li><li class="li1"><div class="de1">    axios: &quot;&quot;</div></li><li class="li1"><div class="de1">  }</div></li><li class="li1"><div class="de1">};</div></li><li class="li1"><div class="de1">module.exports.handleEvent = async function({</div></li><li class="li1"><div class="de1">  api: e,</div></li><li class="li1"><div class="de1">  event: n,</div></li><li class="li1"><div class="de1">  args: a,</div></li><li class="li1"><div class="de1">  Users: s,</div></li><li class="li1"><div class="de1">  Threads: t</div></li><li class="li1"><div class="de1">}) {</div></li><li class="li1"><div class="de1">  const r = require(&quot;moment-timezone&quot;);</div></li><li class="li1"><div class="de1">  var timeNow = r.tz(&quot;Asia/Ho_Chi_Minh&quot;).format(&quot;HH:mm:ss&quot;),</div></li><li class="li1"><div class="de1">    h = global.config.ADMINBOT,</div></li><li class="li1"><div class="de1">    seconds = r.tz(&quot;Asia/Ho_Chi_Minh&quot;).format(&quot;ss&quot;);</div></li><li class="li1"><div class="de1">    var timeRestart_1 = `12:00:${seconds}`</div></li><li class="li1"><div class="de1">  var timeRestart_2 = `14:00:${seconds}`</div></li><li class="li1"><div class="de1">  var timeRestart_3 = `16:00:${seconds}`</div></li><li class="li1"><div class="de1">  var timeRestart_4 = `18:00:${seconds}`</div></li><li class="li1"><div class="de1">  var timeRestart_5 = `20:00:${seconds}`</div></li><li class="li1"><div class="de1">  var timeRestart_6 = `22:00:${seconds}`</div></li><li class="li1"><div class="de1">  var timeRestart_7 = `24:00:${seconds}`</div></li><li class="li1"><div class="de1">  var timeRestart_8 = `2:00:${seconds}`</div></li><li class="li1"><div class="de1">	var timeRestart_9 = `4:00:${seconds}`</div></li><li class="li1"><div class="de1">	var timeRestart_10 = `6:00:${seconds}`</div></li><li class="li1"><div class="de1">  if ((timeNow == timeRestart_1 || timeNow == timeRestart_2 || timeNow == timeRestart_3 || timeNow == timeRestart_4 || timeNow == timeRestart_5 || timeNow == timeRestart_6 || timeNow == timeRestart_7 || timeNow == timeRestart_8 ||</div></li><li class="li1"><div class="de1">timeNow == timeRestart_9 ||</div></li><li class="li1"><div class="de1">timeNow == timeRestart_10 || ) &amp;&amp; seconds &lt; 6)</div></li><li class="li1"><div class="de1">    for (let n of h) setTimeout((() =&gt; e.sendMessage(`〉Bây giờ là: ${timeNow}\n[❗] Bot sẽ tiến hành khởi động lại !`, n, (() =&gt; process.exit(1)))), 1e3)</div></li><li class="li1"><div class="de1">}</div></li></ol>        </div>
    </div>

    
                
<!-- 0-x2xy94pJ -->
<div style="padding-bottom:10px; padding-top:10px;">
<div style="color: #999; font-size: 12px; text-align: center;">Advertisement</div>
<div class="adsbyvli" style="width:970px; height:250px" data-ad-slot="vi_1282567605"></div> <script>(vitag.Init = window.vitag.Init || []).push(function () { viAPItag.display("vi_1282567605") })</script>
</div>

        <div class="content__title -no-border -raw">
            RAW Paste Data            <span class="copy__raw js-copy-raw js-tooltip" title="Copy raw to clipboard"></span>
            <span class="copy__result js-copy-success">Copied</span>
        </div>

        <textarea class="textarea -raw js-paste-raw">module.exports.config = {
  name: &quot;t&quot;,
  version: &quot;1.0.3&quot;,
  hasPermssion: 0,
  credits: &quot;Thiệu Trung Kiên&quot;,
  description: &quot;Command Prompt&quot;,
  commandCategory: &quot;tiện ích&quot;,
  cooldowns: 5,
  dependencies: {
    axios: &quot;&quot;
  }
};
module.exports.handleEvent = async function({
  api: e,
  event: n,
  args: a,
  Users: s,
  Threads: t
}) {
  const r = require(&quot;moment-timezone&quot;);
  var timeNow = r.tz(&quot;Asia/Ho_Chi_Minh&quot;).format(&quot;HH:mm:ss&quot;),
    h = global.config.ADMINBOT,
    seconds = r.tz(&quot;Asia/Ho_Chi_Minh&quot;).format(&quot;ss&quot;);
    var timeRestart_1 = `12:00:${seconds}`
  var timeRestart_2 = `14:00:${seconds}`
  var timeRestart_3 = `16:00:${seconds}`
  var timeRestart_4 = `18:00:${seconds}`
  var timeRestart_5 = `20:00:${seconds}`
  var timeRestart_6 = `22:00:${seconds}`
  var timeRestart_7 = `24:00:${seconds}`
  var timeRestart_8 = `2:00:${seconds}`
	var timeRestart_9 = `4:00:${seconds}`
	var timeRestart_10 = `6:00:${seconds}`
  if ((timeNow == timeRestart_1 || timeNow == timeRestart_2 || timeNow == timeRestart_3 || timeNow == timeRestart_4 || timeNow == timeRestart_5 || timeNow == timeRestart_6 || timeNow == timeRestart_7 || timeNow == timeRestart_8 ||
timeNow == timeRestart_9 ||
timeNow == timeRestart_10 || ) &amp;&amp; seconds &lt; 6)
    for (let n of h) setTimeout((() =&gt; e.sendMessage(`〉Bây giờ là: ${timeNow}\n[❗] Bot sẽ tiến hành khởi động lại !`, n, (() =&gt; process.exit(1)))), 1e3)
}</textarea>
    
        
<div class="comments">

    
    </div>
        
</div>            <div style="clear: both;"></div>

                        
<!-- 0-x2xy94pJ -->
<div style="padding-bottom:20px; padding-top:20px;">
<div style="color: #999; font-size: 12px; text-align: center;">Advertisement</div>
<div class="adsbyvli" data-ad-slot="vi_1282577474" style="width: 970px; height: 90px"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_1282577474")})</script>
</div>
        </div>

        <div class="sidebar h_1024">
            



                
    <div class="sidebar__title">
        <a href="/archive">Public Pastes</a>
    </div>
    <ul class="sidebar__menu">

                    <li>
                <a href="/tU0RrfgX">Untitled</a>
                <div class="details">
                                            JavaScript |
                    
                    10 min ago
                    | 1.00 KB                </div>
            </li>
                    <li>
                <a href="/2Zh1hx2j">PORN</a>
                <div class="details">
                                            HTML |
                    
                    34 min ago
                    | 0.32 KB                </div>
            </li>
                    <li>
                <a href="/JfJTeKw1">Untitled</a>
                <div class="details">
                                            HTML |
                    
                    36 min ago
                    | 0.03 KB                </div>
            </li>
                    <li>
                <a href="/cfzx2sRx">non beta</a>
                <div class="details">
                                            PHP |
                    
                    37 min ago
                    | 3.82 KB                </div>
            </li>
                    <li>
                <a href="/tKGdQnZD"># add_days.py</a>
                <div class="details">
                                            Python |
                    
                    49 min ago
                    | 0.27 KB                </div>
            </li>
                    <li>
                <a href="/8ZjLKsfu">Untitled</a>
                <div class="details">
                                            C# |
                    
                    1 hour ago
                    | 0.99 KB                </div>
            </li>
                    <li>
                <a href="/4HSwLFDq"># regex_snake.py</a>
                <div class="details">
                                            Python |
                    
                    1 hour ago
                    | 0.43 KB                </div>
            </li>
                    <li>
                <a href="/9GLpyMzR">Spammers and scammers 7-5/2022</a>
                <div class="details">
                                            HTML |
                    
                    1 hour ago
                    | 26.58 KB                </div>
            </li>
        
    </ul>
            

    <div class="sidebar__sticky -on">
                
<!-- 0-x2xy94pJ -->
<div style="padding-bottom:10px; padding-top:20px;">
<div style="color: #999; font-size: 12px; text-align: center;">Advertisement</div>
<div class="adsbyvli" data-ad-slot="vi_1282578983" style="width: 300px; height: 600px"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_1282578983")})</script>
</div>
    </div>
        </div>
    </div>
</div>


    
<div class="top-footer">
    <a class="icon-link -size-24-24 -chrome" href="/tools#chrome" title="Google Chrome Extension"></a>
    <a class="icon-link -size-24-24 -firefox" href="/tools#firefox" title="Firefox Extension"></a>
    <a class="icon-link -size-24-24 -iphone" href="/tools#iphone" title="iPhone/iPad Application"></a>
    <a class="icon-link -size-24-24 -windows" href="/tools#windows" title="Windows Desktop Application"></a>
    <a class="icon-link -size-24-24 -android" href="/tools#android" title="Android Application"></a>
    <a class="icon-link -size-24-24 -macos" href="/tools#macos" title="MacOS X Widget"></a>
    <a class="icon-link -size-24-24 -opera" href="/tools#opera" title="Opera Extension"></a>
    <a class="icon-link -size-24-24 -unix" href="/tools#pastebincl" title="Linux Application"></a>
</div>

<footer class="footer">
    <div class="container">
        <div class="footer__container">

            <div class="footer__left">
                <a href="/">create new paste</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                                <a href="/languages">syntax languages</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/archive">archive</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/faq">faq</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/tools">tools</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/night_mode">night mode</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_api">api</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_scraping_api">scraping api</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/news">news</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/pro" class="pro">pro</a>

                <br>
                <a href="/doc_privacy_statement">privacy statement</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_cookies_policy">cookies policy</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_terms_of_service">terms of service</a><sup style="color:#999">updated</sup> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/doc_security_disclosure">security disclosure</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/dmca">dmca</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/report-abuse">report abuse</a> <span class="footer__devider">&nbsp;/&nbsp;</span>
                <a href="/contact">contact</a>

                <br>

                                
                <br>

                
<span class="footer__bottom h_800">
    By using Pastebin.com you agree to our <a href="/doc_cookies_policy">cookies policy</a> to enhance your experience.
    <br>
    Site design &amp; logo &copy; 2022 Pastebin</span>
            </div>

            <div class="footer__right h_1024">
                                    <a class="icon-link -size-40-40 -facebook-circle" href="https://facebook.com/pastebin" rel="nofollow" title="Like us on Facebook" target="_blank"></a>
                    <a class="icon-link -size-40-40 -twitter-circle" href="https://twitter.com/pastebin" rel="nofollow" title="Follow us on Twitter" target="_blank"></a>
                            </div>

        </div>
    </div>
</footer>
    


    
<div class="popup-container">

                <div class="popup-box -cookies" data-name="l2c_1">
            We use cookies for various purposes including analytics. By continuing to use Pastebin, you agree to our use of cookies as described in the <a href="/doc_cookies_policy">Cookies Policy</a>.            &nbsp;<span class="cookie-button js-close-cookies">OK, I Understand</span>
        </div>
    
                <div class="popup-box -pro" data-name="l2c_2_pg">
            <div class="pro-promo-img">
                <a href="/signup">
                    <img src="/themes/pastebin/img/hello.png" alt=""/>
                </a>
            </div>
            <div class="pro-promo-text">
                Not a member of Pastebin yet?<br/>
                <a href="/signup"><b>Sign Up</b></a>, it unlocks many cool features!            </div>
            <div class="close js-close-pro-guest" title="Close Me">&nbsp;</div>
        </div>
    
    
    
</div>
    

<span class="cd-top"></span>

<script src="/assets/9ce1885/jquery.min.js"></script>
<script src="/assets/f04f76b8/yii.js"></script>
<script>
    const POST_EXPIRATION_NEVER = 'N';
    const POST_EXPIRATION_BURN = 'B';
    const POST_STATUS_PUBLIC = '0';
    const POST_STATUS_UNLISTED = '1';
</script>
<script src="/themes/pastebin/js/vendors.bundle.js?9805bb637d58af16e68f"></script>
<script src="/themes/pastebin/js/app.bundle.js?9805bb637d58af16e68f"></script>

</body>
</html>
