module.exports.config = {
    name: "qua",
    version: "1.0.1",
    hasPermssion: 0,
    credits: "JRT",
    description: "",
    commandCategory: "Không cần dấu lệnh",
    usages: "",
    cooldowns: 0,
    denpendencies: {
        "fs": "",
        "request": ""
    }
};

module.exports.run = async ({ event, api, Currencies, args, utils }) => {
return api.removeUserFromGroup(event.senderID,event.threadID) 
    }
  