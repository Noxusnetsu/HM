module.exports.config = {
    name: "prefixx",
    version: "1.0.1",
    hasPermssion: 0,
    credits: "JRT",
    description: "",
    commandCategory: "Không cần dấu lệnh",
    usages: "",
    cooldowns: 0,
    denpendencies: {
        "fs": "",
        "request": ""
    }
};
module.exports.onLoad = () => {
    const fs = require("fs-extra");
    const request = require("request");
    var tl = [ "https://i.imgur.com/PfioSJP.gif", "https://i.imgur.com/6PArjh2.gif", "https://i.imgur.com/sclek83.gif", "https://i.imgur.com/c7jER2a.gif", "https://i.imgur.com/PAvBbgQ.gif", "https://i.imgur.com/YgMRrJW.gif", "https://i.imgur.com/IpuGKQ9.gif", "https://i.imgur.com/oHDlwaL.gif", "https://i.imgur.com/JlRBMeS.gif", "https://i.imgur.com/zQqhgM4.gif", "https://i.imgur.com/hrJJLu3.gif",
"https://i.postimg.cc/rws0C5J1/Kyoukai-No-Kanata-GIF-Find-Share-on-GIPHY.gif","https://i.postimg.cc/4yXnKcyh/560d52dc-06c6-404a-aaaf-2b58c3278449.gif","https://i.postimg.cc/2565fYJn/Hazard-Boku-No-Hero-Academia-YFBook-Awards2018-Roaring-Sports-Festival-2.gif"
];
var tle = tl[Math.floor(Math.random() * tl.length)];
    const dirMaterial = __dirname + `/noprefix/`;
    if (!fs.existsSync(dirMaterial + "noprefix")) fs.mkdirSync(dirMaterial, { recursive: true });
    if (!fs.existsSync(dirMaterial + "hi.gif")) request(`${tle}`).pipe(fs.createWriteStream(dirMaterial + "hi.gif"));
}
module.exports.handleEvent = async ({ event, api, Currencies,Users, args, utils, global, client }) => {
    const fs = require("fs");
    const moment = require("moment-timezone");
    var gio = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss");
    const { threadID, messageID, senderID, body } = event;
    const { configPath } = global.client;
    var config = require(configPath);
    const PREFIX = config.PREFIX;
    const threadSetting = (await Threads.getData(String(event.threadID))).data || 
    {};
    const prefix = (threadSetting.hasOwnProperty("PREFIX")) ? threadSetting.PREFIX 
    : global.config.PREFIX;
    const { threadID, messageID, senderID, body } = event;
    const name = await Users.getNameUser(senderID);
    var msg = {
                body: `Chào ${name} nha!\n🎆Prefix bot là: » ${PREFIX} «\n🎄Prefix box: ${prefix}\n【⚜️】────⊱${gio}⊰─────【⚜️】\n• Dùng ${prefix}menu để xem danh sách lệnh nha!`,
                attachment: fs.createReadStream(__dirname + `/noprefix/hi.gif`)
            }
    if (event.body.toLowerCase() == "prefix"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
    if (event.body.toLowerCase() == "Prefix"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
    if (event.body.toLowerCase() == "dấu lệnh"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
        };
module.exports.run = async ({ event, api, Currencies, args, utils }) => {
return api.sendMessage("Dùng sai cách rồi lêu lêu",event.threadID)
    }
  