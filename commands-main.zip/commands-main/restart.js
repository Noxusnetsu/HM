module.exports.config = {
	name: "restart",
	version: "1.0.0",
	hasPermssion: 2,
	credits: "Mirai Team",
	description: "Khởi Động Lại Bot.",
	commandCategory: "admin",
	cooldowns: 0
        };
module.exports.run = async function({ api, event, Threads })
{
	const fs = require("fs");
    const axios = require('axios');
    const img = ["https://i.imgur.com/PfioSJP.gif", "https://i.imgur.com/6PArjh2.gif", "https://i.imgur.com/sclek83.gif", "https://i.imgur.com/c7jER2a.gif", "https://i.imgur.com/PAvBbgQ.gif", "https://i.imgur.com/YgMRrJW.gif", "https://i.imgur.com/IpuGKQ9.gif", "https://i.imgur.com/oHDlwaL.gif", "https://i.imgur.com/JlRBMeS.gif", "https://i.imgur.com/zQqhgM4.gif", "https://i.imgur.com/hrJJLu3.gif",
"https://i.postimg.cc/rws0C5J1/Kyoukai-No-Kanata-GIF-Find-Share-on-GIPHY.gif","https://i.postimg.cc/4yXnKcyh/560d52dc-06c6-404a-aaaf-2b58c3278449.gif","https://i.postimg.cc/2565fYJn/Hazard-Boku-No-Hero-Academia-YFBook-Awards2018-Roaring-Sports-Festival-2.gif"]
	var path = __dirname + "/cache/restart.gif"
	var rdimg = img[Math.floor(Math.random() * img.length)]; 
	const imgP = []
	let dowloadIMG = (await axios.get(rdimg, { responseType: "arraybuffer" } )).data; 
	fs.writeFileSync(path, Buffer.from(dowloadIMG, "utf-8") );
	imgP.push(fs.createReadStream(path))
	 api.sendMessage("Địt con mẹ chờ bố mày 1p khởi động lại ... ",event.threadID,attachment: imgP, () process.exit(1)) 
	}